/* Website Kelas 8.6 — Supabase database + online photo storage */
const { createClient } = supabase;
const client = createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
const DATA_ID = "kelas86";
const BUCKET = "kelas86-foto";
const defaultData = {
  title:"Kelas 8.6", year:"Angkatan 2026/2027",
  teacher:{name:"Nama Wali Kelas",note:"Wali Kelas",photo:""},
  officers:[
    {role:"Ketua Kelas",name:"Nama Ketua",photo:""},{role:"Wakil Ketua",name:"Nama Wakil",photo:""},
    {role:"Sekretaris 1",name:"Nama Sekretaris 1",photo:""},{role:"Sekretaris 2",name:"Nama Sekretaris 2",photo:""},
    {role:"Bendahara 1",name:"Nama Bendahara 1",photo:""},{role:"Bendahara 2",name:"Nama Bendahara 2",photo:""}
  ],
  members:Array.from({length:29},(_,i)=>({name:`Nama Anggota ${i+1}`,photo:""})),
  subjects:[
    {day:"Senin",periods:[{subject:"Mata Pelajaran 1",teacher:"Nama Guru"},{subject:"Mata Pelajaran 2",teacher:"Nama Guru"},{subject:"Mata Pelajaran 3",teacher:"Nama Guru"},{subject:"Mata Pelajaran 4",teacher:"Nama Guru"}]},
    {day:"Selasa",periods:[{subject:"Mata Pelajaran 1",teacher:"Nama Guru"},{subject:"Mata Pelajaran 2",teacher:"Nama Guru"},{subject:"Mata Pelajaran 3",teacher:"Nama Guru"},{subject:"Mata Pelajaran 4",teacher:"Nama Guru"}]},
    {day:"Rabu",periods:[{subject:"Mata Pelajaran 1",teacher:"Nama Guru"},{subject:"Mata Pelajaran 2",teacher:"Nama Guru"},{subject:"Mata Pelajaran 3",teacher:"Nama Guru"},{subject:"Mata Pelajaran 4",teacher:"Nama Guru"}]},
    {day:"Kamis",periods:[{subject:"Mata Pelajaran 1",teacher:"Nama Guru"},{subject:"Mata Pelajaran 2",teacher:"Nama Guru"},{subject:"Mata Pelajaran 3",teacher:"Nama Guru"},{subject:"Mata Pelajaran 4",teacher:"Nama Guru"}]},
    {day:"Jumat",periods:[{subject:"Mata Pelajaran 1",teacher:"Nama Guru"},{subject:"Mata Pelajaran 2",teacher:"Nama Guru"},{subject:"Mata Pelajaran 3",teacher:"Nama Guru"},{subject:"Mata Pelajaran 4",teacher:"Nama Guru"}]}
  ],
  duty:[
    {day:"Senin",names:"Nama siswa yang piket"},{day:"Selasa",names:"Nama siswa yang piket"},
    {day:"Rabu",names:"Nama siswa yang piket"},{day:"Kamis",names:"Nama siswa yang piket"},{day:"Jumat",names:"Nama siswa yang piket"}
  ]
};
let siteData = structuredClone(defaultData);
let adminSession = false;
const $ = id => document.getElementById(id);
function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function placeholder(name){return "data:image/svg+xml;charset=UTF-8,"+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="500" height="600"><rect width="100%" height="100%" fill="#e5eef7"/><circle cx="250" cy="210" r="85" fill="#b8cce0"/><path d="M80 570 Q90 360 250 360 Q410 360 420 570" fill="#b8cce0"/><text x="250" y="590" font-size="24" text-anchor="middle" fill="#12345a">${name}</text></svg>`);}
function photoSrc(item){return item.photo || placeholder("Foto belum ada");}
function card(item,role=""){return `<article class="card"><img class="photo" src="${esc(photoSrc(item))}" alt="Foto ${esc(item.name||role)}"><div class="card-body"><h3>${esc(item.name||"Nama belum diisi")}</h3><p class="role">${esc(role||item.role||"Anggota Kelas")}</p>${item.note?`<p class="description">${esc(item.note)}</p>`:""}</div></article>`;}
async function loadData(){
  const {data,error}=await client.from("site_content").select("data").eq("id",DATA_ID).maybeSingle();
  if(error){console.error(error);showStatus("Belum bisa membaca database. Periksa URL/key Supabase dan jalankan supabase-setup.sql.","error");return;}
  if(data?.data) siteData={...structuredClone(defaultData),...data.data};
  renderPage();
}
function showStatus(msg,type="ok"){const el=$("status");if(el){el.textContent=msg;el.className="status "+(type==="error"?"error":"");el.classList.remove("hidden");}}
function renderPage(){
 const page=document.body.dataset.page;
 if(page==="home"){
   $("site-title").textContent=siteData.title||"Kelas 8.6"; $("site-year").textContent=siteData.year||"Angkatan 2026/2027";
   $("teacher-card").innerHTML=card(siteData.teacher,"Wali Kelas");
   $("officer-grid").innerHTML=siteData.officers.map(o=>card(o,o.role)).join("");
 }
 if(page==="members") $("member-grid").innerHTML=siteData.members.map((m,i)=>card(m,`Anggota ${i+1}`)).join("");
 if(page==="schedule"){
   $("subject-body").innerHTML=siteData.subjects.map(d=>`<tr><th>${esc(d.day)}</th><td>${d.periods.map((p,i)=>`<div><b>${i+1}.</b> ${esc(p.subject)} <span class="small">— ${esc(p.teacher)}</span></div>`).join("")}</td></tr>`).join("");
   $("duty-body").innerHTML=siteData.duty.map(d=>`<tr><th>${esc(d.day)}</th><td>${esc(d.names)}</td></tr>`).join("");
 }
}
async function saveData(){
 const {error}=await client.from("site_content").upsert({id:DATA_ID,data:siteData,updated_at:new Date().toISOString()});
 if(error){showStatus("Gagal menyimpan: "+error.message,"error");return false;}
 showStatus("Berhasil disimpan online. Perubahan dapat dilihat di perangkat lain.");renderPage();return true;
}
async function uploadPhoto(file,path){
 if(!file) return "";
 if(!file.type.startsWith("image/")) throw new Error("Pilih file gambar.");
 if(file.size>5*1024*1024) throw new Error("Ukuran foto maksimal 5 MB.");
 const ext=(file.name.split(".").pop()||"jpg").toLowerCase().replace(/[^a-z0-9]/g,"")||"jpg";
 const key=`${path}-${Date.now()}.${ext}`;
 const {error}=await client.storage.from(BUCKET).upload(key,file,{upsert:true,contentType:file.type});
 if(error) throw error;
 return client.storage.from(BUCKET).getPublicUrl(key).data.publicUrl;
}
async function login(){
 const email=$("admin-email").value.trim(), password=$("admin-password").value;
 const {error}=await client.auth.signInWithPassword({email,password});
 if(error){showStatus("Login gagal: "+error.message,"error");return;}
 adminSession=true;$("admin-panel").classList.remove("hidden");showStatus("Login admin berhasil. Kamu bisa mengubah isi website.");fillEditor();
}
async function logout(){await client.auth.signOut();adminSession=false;$("admin-panel")?.classList.add("hidden");showStatus("Kamu sudah keluar dari admin.");}
function fillEditor(){
 if(!$("editor")) return;
 $("edit-title").value=siteData.title||"";$("edit-year").value=siteData.year||"";
 $("edit-teacher").value=siteData.teacher.name||"";
 $("officer-editor").innerHTML=siteData.officers.map((o,i)=>`<div class="panel"><h3>${esc(o.role)}</h3><label>Nama</label><input id="officer-name-${i}" value="${esc(o.name)}"><label>Ganti foto</label><input type="file" accept="image/*" id="officer-photo-${i}"><p class="small">Foto saat ini: ${o.photo?"sudah tersimpan online":"belum dipasang"}</p></div>`).join("");
 $("member-editor").innerHTML=siteData.members.map((m,i)=>`<div class="panel"><h3>Anggota ${i+1}</h3><label>Nama</label><input id="member-name-${i}" value="${esc(m.name)}"><label>Ganti foto</label><input type="file" accept="image/*" id="member-photo-${i}"><p class="small">${m.photo?"Foto sudah tersimpan online":"Foto belum dipasang"}</p></div>`).join("");
 $("teacher-photo-status").textContent=siteData.teacher.photo?"Foto wali kelas sudah tersimpan online":"Foto wali kelas belum dipasang";
 $("subject-editor").innerHTML=siteData.subjects.map((d,di)=>`<div class="panel"><h3>${esc(d.day)}</h3>${d.periods.map((p,pi)=>`<div class="field-grid"><div><label>Jam ${pi+1} — Mata pelajaran</label><input id="sub-${di}-${pi}" value="${esc(p.subject)}"></div><div><label>Nama guru</label><input id="teach-${di}-${pi}" value="${esc(p.teacher)}"></div></div>`).join("")}</div>`).join("");
 $("duty-editor").innerHTML=siteData.duty.map((d,i)=>`<div class="field-grid"><div><label>${esc(d.day)}</label><input id="duty-${i}" value="${esc(d.names)}"></div></div>`).join("");
}
async function saveEditor(){
 if(!adminSession){showStatus("Login admin terlebih dahulu.","error");return;}
 siteData.title=$("edit-title").value;siteData.year=$("edit-year").value;siteData.teacher.name=$("edit-teacher").value;
 const teacherFile=$("teacher-photo")?.files?.[0];
 try{
   if(teacherFile)siteData.teacher.photo=await uploadPhoto(teacherFile,"wali-kelas");
   for(let i=0;i<siteData.officers.length;i++){
     siteData.officers[i].name=$(`officer-name-${i}`).value;
     const f=$(`officer-photo-${i}`).files[0];if(f)siteData.officers[i].photo=await uploadPhoto(f,`pengurus-${i}`);
   }
   for(let i=0;i<siteData.members.length;i++){
     siteData.members[i].name=$(`member-name-${i}`).value;
     const f=$(`member-photo-${i}`).files[0];if(f)siteData.members[i].photo=await uploadPhoto(f,`anggota-${i+1}`);
   }
   siteData.subjects.forEach((d,di)=>d.periods.forEach((p,pi)=>{p.subject=$(`sub-${di}-${pi}`).value;p.teacher=$(`teach-${di}-${pi}`).value;}));
   siteData.duty.forEach((d,i)=>d.names=$(`duty-${i}`).value);
   const ok=await saveData();if(ok)fillEditor();
 }catch(e){showStatus("Foto gagal diunggah: "+e.message,"error");}
}
async function changePassword(){
 const password=$("new-password").value;
 if(password.length<8){showStatus("Kata sandi baru minimal 8 karakter.","error");return;}
 const {error}=await client.auth.updateUser({password});
 if(error)showStatus("Gagal mengubah kata sandi: "+error.message,"error");
 else { $("new-password").value="";showStatus("Kata sandi admin berhasil diubah.");}
}
function setup(){
 const page=document.body.dataset.page;
 const menuBtn=$("dots"),menu=$("admin-menu");
 menuBtn?.addEventListener("click",()=>menu.classList.toggle("hidden"));
 $("login-btn")?.addEventListener("click",login);$("logout-btn")?.addEventListener("click",logout);
 $("save-btn")?.addEventListener("click",saveEditor);$("change-password-btn")?.addEventListener("click",changePassword);
 $("teacher-photo")?.addEventListener("change",()=>{const f=$("teacher-photo").files[0];if(f)$("teacher-photo-status").textContent=`Dipilih: ${f.name}`;});
 client.auth.getSession().then(({data})=>{if(data.session){adminSession=true;if($("admin-panel")){$("admin-panel").classList.remove("hidden");fillEditor();}}});
 loadData();
}
document.addEventListener("DOMContentLoaded",setup);
