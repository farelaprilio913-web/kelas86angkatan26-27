PANDUAN WEBSITE KELAS 8.6 — VERSI DATABASE ONLINE

ISI PAKET
- index.html: Beranda, foto wali kelas, pengurus, dan panel admin.
- anggota.html: Halaman 29 foto anggota.
- jadwal.html: Halaman jadwal mata pelajaran + nama guru dan jadwal piket Senin–Jumat.
- app.js dan style.css: fungsi dan tampilan bersama.
- config.js: tempat memasukkan Project URL dan anon/publishable key Supabase.
- supabase-setup.sql: membuat tabel database, aturan akses, dan penyimpanan foto online.

PENTING
Versi ini memakai Supabase agar foto dan perubahan tersimpan online dan terlihat di HP lain.
Jangan gunakan file HTML tunggal versi localStorage untuk kebutuhan sinkronisasi.
Jangan pernah memasukkan service_role key ke file website. Hanya gunakan anon/publishable key.

LANGKAH SETUP
1. Buat project di https://supabase.com/ dan tunggu sampai siap.
2. Di Supabase, buka SQL Editor > New query. Buka file supabase-setup.sql, salin seluruh isinya, tempel di SQL Editor, lalu tekan Run.
3. Buka Project Settings > API (atau bagian Connect/API keys). Salin Project URL dan anon/publishable key.
4. Buka config.js dan ganti:
   TEMPEL_PROJECT_URL_DI_SINI
   TEMPEL_ANON_ATAU_PUBLISHABLE_KEY_DI_SINI
   dengan nilai dari project Supabase. Simpan file.
5. Buat akun admin: Supabase > Authentication > Users > Add user / Create user. Masukkan email dan kata sandi admin yang kuat. Jika ada pilihan confirm email, pastikan akun sudah dikonfirmasi atau atur sesuai pengaturan project.
6. Unggah SEMUA file dalam folder ini ke project Vercel yang benar. Pastikan index.html berada di folder root, bukan di dalam folder tambahan. Deploy ulang.
   Jika project Vercel terhubung ke GitHub, unggah file melalui repository dan commit/push. Jika menggunakan Vercel CLI, deploy folder ini. Pastikan domain yang dibuka adalah domain project yang benar.
7. Buka website. Tekan menu titik tiga, login dengan email dan kata sandi admin Supabase.
8. Isi nama/foto pengurus, wali kelas, dan anggota. Isi mata pelajaran + nama guru dan jadwal piket. Tekan “Simpan perubahan online”.
9. Coba buka website dari HP lain. Foto yang diunggah dan data yang disimpan seharusnya sama karena berada di Supabase.
10. Untuk mengubah kata sandi admin, login dulu lalu gunakan bagian “Ubah kata sandi admin” di panel admin. Kata sandi baru minimal 8 karakter.

CATATAN
- Nama, jadwal, dan foto awal adalah contoh; ganti dengan data kelas yang benar.
- Foto maksimal 5 MB per gambar. Disarankan JPG/WebP yang dikompres agar unggah lebih cepat.
- Jika halaman menampilkan error koneksi, periksa Project URL/key, SQL yang dijalankan, dan bahwa akun admin bisa login.
- Akun admin dibuat melalui Supabase Authentication. Jangan menaruh password admin di HTML.
- File ini mengatur siapa yang boleh menulis lewat login Supabase. Jangan mengubah kebijakan database menjadi public write.
- Minta izin sebelum mengunggah foto teman dan wali kelas.
