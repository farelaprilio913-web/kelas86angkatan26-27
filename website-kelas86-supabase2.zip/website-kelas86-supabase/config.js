// Isi dua nilai ini dari Supabase: Project Settings > API
// Gunakan Project URL dan anon/publishable key. Jangan pernah masukkan service_role key ke website.
window.SUPABASE_URL = "https://bmwmdwlfqrkdbnaezlmp.supabase.co.";
window.SUPABASE_ANON_KEY = "sb_publishable_gqmwqMKf8tRMvogUKWyEuQ_Tl1qsT4Y";
