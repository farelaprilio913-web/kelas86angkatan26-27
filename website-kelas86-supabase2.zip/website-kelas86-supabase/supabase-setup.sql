-- Jalankan seluruh SQL ini di Supabase > SQL Editor > New query > Run.
-- Isi situs dibaca publik, tetapi hanya pengguna yang login boleh mengubahnya.
create table if not exists public.site_content (
  id text primary key,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.site_content enable row level security;
drop policy if exists "Public can read site content" on public.site_content;
create policy "Public can read site content" on public.site_content
  for select to anon, authenticated using (true);
drop policy if exists "Authenticated can insert site content" on public.site_content;
create policy "Authenticated can insert site content" on public.site_content
  for insert to authenticated with check (true);
drop policy if exists "Authenticated can update site content" on public.site_content;
create policy "Authenticated can update site content" on public.site_content
  for update to authenticated using (true) with check (true);

insert into public.site_content(id, data)
values ('kelas86', '{"title":"Kelas 8.6","year":"Angkatan 2026/2027"}'::jsonb)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('kelas86-foto', 'kelas86-foto', true, 5242880, array['image/jpeg','image/png','image/webp','image/gif'])
on conflict (id) do update set public = true, file_size_limit = 5242880;

drop policy if exists "Public can view class photos" on storage.objects;
create policy "Public can view class photos" on storage.objects
  for select to anon, authenticated using (bucket_id = 'kelas86-foto');
drop policy if exists "Logged in admin can upload class photos" on storage.objects;
create policy "Logged in admin can upload class photos" on storage.objects
  for insert to authenticated with check (bucket_id = 'kelas86-foto');
drop policy if exists "Logged in admin can update class photos" on storage.objects;
create policy "Logged in admin can update class photos" on storage.objects
  for update to authenticated using (bucket_id = 'kelas86-foto') with check (bucket_id = 'kelas86-foto');
drop policy if exists "Logged in admin can delete class photos" on storage.objects;
create policy "Logged in admin can delete class photos" on storage.objects
  for delete to authenticated using (bucket_id = 'kelas86-foto');
